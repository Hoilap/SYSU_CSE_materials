class myAI{
	public:
		myAI(){}
		bool chose_act_first(const int arr[]);
		void action(const int arr[],int& mission_idx,int& step);
};