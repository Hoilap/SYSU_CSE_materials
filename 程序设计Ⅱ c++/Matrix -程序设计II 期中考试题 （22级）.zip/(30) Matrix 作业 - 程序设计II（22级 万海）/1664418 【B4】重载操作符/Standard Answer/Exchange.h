#ifndef Matrix_H
#define Matrix_H
#include <iostream>
using namespace std;


class Exchange
{
    public:
	void operator()(int&, int&);
};

#endif
