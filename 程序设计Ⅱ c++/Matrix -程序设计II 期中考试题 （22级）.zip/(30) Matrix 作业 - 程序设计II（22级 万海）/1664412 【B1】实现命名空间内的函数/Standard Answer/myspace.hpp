#include <iostream>

namespace myspace{

void cout();
void read();
}
